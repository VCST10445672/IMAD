package com.example.arrays

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import java.util.Arrays

class MainActivity : AppCompatActivity() {

    val teams = arrayOf<String>("Sundowns", "Wits", "Pirates", "Chiefs", "Cape Town")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtDisp = findViewById<TextView>(R.id.txtDisp)

        teams[0] = "Sundowns?"

        val disp = teams.joinToString("\n")
//        var disp = ""
//        var i = 0
//        while (i < teams.size) {
//            disp += "${teams[i]}\n"
//            i++
//        }
        txtDisp.text = disp
//        for (i in 0..teams.count()-1){
//            disp += "${teams[i]}\n"
//            txtDisp.text = "$disp"}


    }
}