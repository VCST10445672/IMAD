package ifelse;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        // Declaration
        int k;

        // Output prompt for input
        String input = JOptionPane.showInputDialog(null, "Enter Mark");

        // Convert input to integer
        k = Integer.parseInt(input);

        // Check if the input is within the valid range
        if (k < 101 && k >= 0) {
            // Check if the mark is less than 51
            if (k < 50) {
                // Check if the mark is less than 30
                if (k < 30) {
                    // Output fail if the mark is less than 30
                    JOptionPane.showMessageDialog(null, "You failed");
                } else {
                    // Output supplementary if the mark is between 30 and 50
                    JOptionPane.showMessageDialog(null, "You qualify for supplementary");
                }
            } else {
                // Check if the mark is less than 75
                if (k < 75) {
                    // Output pass if the mark is between 51 and 74
                    JOptionPane.showMessageDialog(null, "You passed");
                } else {
                    // Output distinction if the mark is 75 or above
                    JOptionPane.showMessageDialog(null, "You have passed with a Distinction");
                }
            }
        } else {
            // Output a message if the input is not within the valid range
            JOptionPane.showMessageDialog(null, "Please enter a valid mark.");
        }
    }
}