package com.example.rgpprogram

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnDisp = findViewById<Button>(R.id.btnDisp)
        val txtDisp = findViewById<TextView>(R.id.txtDisp)
        val radRange = findViewById<RadioGroup>(R.id.radRange)

        btnDisp.setOnClickListener {
            val rangeSelect = radRange.checkedRadioButtonId
            if (rangeSelect == -1)
                txtDisp.text = "Please select an option"
            else{
                if (rangeSelect == R.id.rbtA)
                    txtDisp.text = "100 - 91"
                else if (rangeSelect == R.id.rbtB)
                    txtDisp.text = "90 - 81"
                else if (rangeSelect == R.id.rbtC)
                    txtDisp.text = "80 - 71"
                else if (rangeSelect == R.id.rbtD)
                    txtDisp.text = "70 - 61"
                else if (rangeSelect == R.id.rbtE)
                    txtDisp.text = "60 - 51"
                else if (rangeSelect == R.id.rbtF)
                    txtDisp.text = "50 - 41"
                else if (rangeSelect == R.id.rbtG)
                    txtDisp.text = "40 - 31"
                else if (rangeSelect == R.id.rbtH)
                    txtDisp.text = "30 - 21"
                else if (rangeSelect == R.id.rbtI)
                    txtDisp.text = "20 - 11"
            }
        }
    }
}