package com.example.mymovieapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val Tag = "Player Data"
        val currentYear = 2022
        var ageOfPlayer = 22
        var name: String
        name = "Bob"
        Log.v(Tag, name)
    }
}