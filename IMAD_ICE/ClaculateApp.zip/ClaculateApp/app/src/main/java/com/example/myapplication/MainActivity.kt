package com.example.myapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    private lateinit var edtNum1: EditText
    private lateinit var edtNum2: EditText
    private lateinit var txtResult: TextView
    private lateinit var btnCalculate: Button
    private lateinit var btnDif: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtNum1 = findViewById(R.id.edtNum1)
        edtNum2 = findViewById(R.id.edtNum2)
        txtResult = findViewById(R.id.txtResult)
        btnCalculate = findViewById(R.id.btnCalculate)
        btnDif = findViewById(R.id.btnDif)

        btnDif.setOnClickListener {
            calculateDif()
        }

        btnCalculate.setOnClickListener {
            calculateSum()
        }
    }
    private fun calculateSum() {
        val num1 = edtNum1.text.toString().toInt()
        val num2 = edtNum2.text.toString().toInt()
        val sum = num1 + num2
        txtResult.text = "Result: $sum"
    }
    private fun calculateDif() {
        val num1 = edtNum1.text.toString().toInt()
        val num2 = edtNum2.text.toString().toInt()
        val sum = num1 - num2
        txtResult.text = "Result: $sum"
    }

}
