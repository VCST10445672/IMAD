package com.example.paraarays

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtProName = findViewById<EditText>(R.id.edtProName)
        val edtPrice = findViewById<EditText>(R.id.edtPrice)
        val btnPop = findViewById<Button>(R.id.btnPop)
        val btnDisp = findViewById<Button>(R.id.btnDisp)
        val btnClear = findViewById<Button>(R.id.btnClear)
        val txtDisp = findViewById<TextView>(R.id.txtDisp)

        val arrProName = arrayOfNulls<String>(5)
        val arrQty = IntArray(5)
        val arrPrice = DoubleArray(5)
        val arrStockValue = DoubleArray(5)

        btnPop.setOnClickListener {
            val proName = edtProName.text.toString()
            val price = edtPrice.text.toString().toDoubleOrNull()

            if (proName.isNotEmpty() && price != null) {
                for (i in 0 until 5) {
                    if (arrProName[i] == null) {
                        arrProName[i] = proName

                        //generate random number
                        var randQty = Random.nextInt(1, 98)
                        if (randQty % 2 == 0) {
                            randQty += 2
                        }

                        //populating arrays
                        arrQty[i] = randQty
                        arrPrice[i] = price
                        arrStockValue[i] = randQty * price

                        //Stream line population
                        Toast.makeText(this, "Product added", Toast.LENGTH_LONG).show()
                        edtPrice.text.clear()
                        edtProName.text.clear()
                        edtPrice.requestFocus()

                        break   //exit forloop
                    }
                }
            } else {        //error handeling
                txtDisp.text = "Please enter valid product name and price."
            }
        }

        btnDisp.setOnClickListener {
            txtDisp.text = ""
            for (i in 0 until 5) {
                if (arrProName[i] != null) {
                    txtDisp.append("Name: ${arrProName[i]}  Qty: ${arrQty[i]}  Price: R${arrPrice[i]}  SV: ${arrStockValue[i]}\n")
                }
            }
        }

        btnClear.setOnClickListener {
            edtProName.text.clear()
            edtPrice.text.clear()
            txtDisp.text = ""

            for (i in 0 until 5) {
                arrQty[i] = 0
                arrProName[i] = null
                arrPrice[i] = 0.0
                arrStockValue[i] = 0.0
            }
        }
    }
}