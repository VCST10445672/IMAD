package com.example.productprice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtName= findViewById<EditText>(R.id.edtName)
        val edtQty = findViewById<EditText>(R.id.edtQuantity)
        val edtPrice = findViewById<EditText>(R.id.edtPrice)
        val txtResult = findViewById<TextView>(R.id.txtResult)
        val btnCalc = findViewById<Button>(R.id.btnCalc)
        val btnInc = findViewById<Button>(R.id.btnInc)
        val btnClear = findViewById<Button>(R.id.btnClear)

        btnCalc.setOnClickListener {
            val name = edtName.text.toString()
            val qty = edtQty.text.toString().toInt()
            val price = edtPrice.text.toString().toDouble()

            var obj = product(name, qty, price)
            txtResult.text = "R${obj.computeStock()}"
        }

        btnInc.setOnClickListener {
            val name = edtName.text.toString()
            val qty = edtQty.text.toString().toInt()
            val price = edtPrice.text.toString().toDouble()

            var obj = product(name, qty, price)
            txtResult.text = "R${obj.increaseStock()}"

        }

        btnClear.setOnClickListener {
            edtName.text.clear()
            edtPrice.text.clear()
            edtQty.text.clear()
            txtResult.text = ""
        }
    }

}