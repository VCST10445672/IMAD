package com.example.productprice

class product ( var name : String,
                var quantity : Int,
                var price : Double) {

    fun computeStock() : Double {
        var result = quantity * price
        return result
    }

    fun increaseStock() : Double {
        var stockInc = price * quantity * 1.1
        return stockInc
    }
}