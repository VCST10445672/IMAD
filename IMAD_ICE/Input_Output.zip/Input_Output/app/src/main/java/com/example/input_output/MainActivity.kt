package com.example.input_output

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtName: EditText = findViewById(R.id.edtName)
        val btnClick: Button = findViewById(R.id.btnClick)
        val txtName: TextView = findViewById(R.id.txtName)

        btnClick.setOnClickListener {
            val name = edtName.text.toString()
            if (name.isNotBlank()) {
                txtName.text = "Welcome, $name!"
                val message = "Button Clicked!"
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            } else {
                txtName.text = "Please enter your name"
                Toast.makeText(this, "Button Pressed", Toast.LENGTH_SHORT).show()
            }
        }
    }
}