package com.example.pizzahut

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtPrice = findViewById<TextView>(R.id.txtPrice)
        val btnCalc = findViewById<Button>(R.id.btnCalc)
        val btnClear = findViewById<Button>(R.id.btnClaer)
        val cbxSauce = findViewById<CheckBox>(R.id.cbxSauce)
        val cbxLove = findViewById<CheckBox>(R.id.cbxLove)
        val cbxPotato = findViewById<CheckBox>(R.id.cbxPotato)
        val radSize = findViewById<RadioGroup>(R.id.rgpSize)

        btnCalc.setOnClickListener {
            var totalPrice = 0.0

            if (cbxSauce.isChecked) {
                totalPrice += 1.50
            }
            if (cbxLove.isChecked) {
                totalPrice += 10.21
            }
            if (cbxPotato.isChecked) {
                totalPrice += 1.50
            }

            val selectedSizeId = radSize.checkedRadioButtonId
            val selectedSize = findViewById<RadioButton>(selectedSizeId).text.toString()
            totalPrice += when (selectedSize) {
                "Small" -> 29.99
                "Medium" -> 39.99
                "Large" -> 49.99
                else -> 0.0
            }
            "Your total is: $totalPrice".also { txtPrice.text = it }

        }

        btnClear.setOnClickListener {
            txtPrice.text = "Your total is: "
            cbxSauce.isChecked = false
            cbxLove.isChecked = false
            cbxPotato.isChecked = false
            radSize.clearCheck()
        }
    }
}