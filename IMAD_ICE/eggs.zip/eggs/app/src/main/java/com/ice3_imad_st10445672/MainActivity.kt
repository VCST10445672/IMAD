package com.ice3_imad_st10445672

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import android.view.View

class MainActivity : AppCompatActivity() {

    private lateinit var edtEggs: EditText
    private lateinit var txtDue: TextView
    private lateinit var txtDoz: TextView
    private lateinit var txtLoose: TextView
    private lateinit var btnCalc: Button
    private lateinit var swhImg: Switch
    private lateinit var imgLogo: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imgLogo = findViewById(R.id.imgLogo)
        swhImg = findViewById(R.id.swhImg)

        swhImg.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                // If the Switch is checked, show the ImageView
                imgLogo.visibility = View.VISIBLE
            } else {
                // If the Switch is unchecked, hide the ImageView
                imgLogo.visibility = View.GONE
            }
        }

        edtEggs = findViewById(R.id.edtEggs)
        txtDue = findViewById(R.id.txtDue)
        txtDoz = findViewById(R.id.txtDoz)
        txtLoose = findViewById(R.id.txtLoose)
        btnCalc = findViewById(R.id.btnCalc)


        btnCalc.setOnClickListener {
            calcEggs()
        }

    }

    private fun calcEggs() {
        val eggs = edtEggs.text.toString().toInt()
        val doz = eggs / 12
        val loose = eggs % 12
        val due = doz * 24.99 + loose * 2.6
        txtDue.text = "The Amount due: $due"
        txtDoz.text = "Number of dozens: $doz"
        txtLoose.text = "Number of loose eggs: $loose"
    }
}