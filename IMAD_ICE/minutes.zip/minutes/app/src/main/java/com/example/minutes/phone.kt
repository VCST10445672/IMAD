package com.example.minutes

class phone(var min: Int) {

    fun calcLocalCost(): Double {
        return if (min > 1) {
            (1 * 1.5) + ((min - 1) * 0.07)
        } else {
            0.07
        }
    }

    fun calcInterCost(): Double {
        return if (min > 1) {
            (1 * 7.5) + ((min - 1) * 3.5)
        } else {
            3.5
        }
    }
}