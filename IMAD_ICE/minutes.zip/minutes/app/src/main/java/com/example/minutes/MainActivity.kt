package com.example.minutes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtMin = findViewById<EditText>(R.id.edtMin)
        val txtDisp = findViewById<TextView>(R.id.txtDisp)
        val btnClear = findViewById<Button>(R.id.btnClear)
        val btnInter = findViewById<Button>(R.id.btnInter)
        val btnLocal = findViewById<Button>(R.id.btnLocal)

        btnLocal.setOnClickListener {
            val minText = edtMin.text.toString()
            if (minText.isNotEmpty()) {
                val min = minText.toInt()
                val obj = phone(min)
                txtDisp.text = "R ${obj.calcLocalCost()}"
            } else {
                Toast.makeText(this, "NO!, be better.", Toast.LENGTH_LONG).show()
            }
        }

        btnInter.setOnClickListener {
            val minText = edtMin.text.toString()
            if (minText.isNotEmpty()) {
                val min = minText.toInt()
                val obj = phone(min)
                txtDisp.text = "R ${obj.calcInterCost()}"
            } else {
                Toast.makeText(this, "NO!, be better.", Toast.LENGTH_LONG).show()
            }
        }

        btnClear.setOnClickListener {
            edtMin.text.clear()
            txtDisp.text = ""
        }
    }
}