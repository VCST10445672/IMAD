package com.example.selection_01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtIn = findViewById<EditText>(R.id.edtNum)
        val btnComp = findViewById<Button>(R.id.btnComp)
        val txtDisp = findViewById<TextView>(R.id.txtDisp)

        btnComp.setOnClickListener {
            val cred = edtIn.text.toString().toIntOrNull()

            if (cred == null || cred>120) {
                txtDisp.text ="Invalid input"
            }
//            else {
//            val year = when {
//                cred in 0..30 -> "First"
//                cred in 31..60 -> "Second"
//                cred in 61..90 -> "Third"
//                cred in 91..
//                else -> "Senior"
//            }
//                txtDisp.text = year
            else {
                var year = " "

                if ((cred>= 0) && (cred<=30))
                    year = "First"

                else if ((cred>= 31) && (cred<=60))
                    year ="second"

                else if ((cred>= 61) && (cred<=90))
                    year ="third"

                else
                    year = "senior"

                txtDisp.text="$year"
            }


        }
    }
}