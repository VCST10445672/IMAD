package com.example.student

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var edtTest:EditText
    private lateinit var edtAss:EditText
    private lateinit var btnComp:Button
    private lateinit var btnClear:Button
    private lateinit var txtDisp:TextView
    private var student:Student?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtTest = findViewById(R.id.edtTest)
        edtAss = findViewById(R.id.edtAss)
        btnComp = findViewById(R.id.btnComp)
        btnClear = findViewById(R.id.btnClear)
        txtDisp = findViewById(R.id.txtDisp)

        btnComp.setOnClickListener {
            val testMark = edtTest.text.toString().toDoubleOrNull()?:return@setOnClickListener
            val assMark = edtAss.text.toString().toDoubleOrNull()?:return@setOnClickListener

           // return@setOnClickListener
            student = Student(testMark, assMark)
            val finalMark = student!!.compute()
            txtDisp.text = "Final Mark: $finalMark"
        }

        btnClear.setOnClickListener {
            edtTest.text.clear()
            edtAss.text.clear()
            txtDisp.text = "Final Mark"
        }
    }

}