package com.example.student

class Student(private var testMark: Double, private var assignMark: Double)
{
    init {

    }
    fun setTestMark(mark:Double)
    {
        require(mark in 0.0..100.0){"Test mark must be between 0 - 100"}
        testMark = mark
    }
    fun setAssignmentMark(mark:Double)
    {
        require(mark in 0.0..100.0){"Assignment mark must be between 0 - 100"}
        assignMark = mark
    }
    fun compute():Double{
        return (testMark * 0.6) + (assignMark * 0.4)
    }
}