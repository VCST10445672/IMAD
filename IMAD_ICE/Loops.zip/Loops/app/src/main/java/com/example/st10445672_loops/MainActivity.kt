package com.example.st10445672_loops

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnDisp = findViewById<Button>(R.id.btnDisp)
        val txtDisp = findViewById<TextView>(R.id.txtDisp)
        val edtNum = findViewById<EditText>(R.id.edtNum)

        btnDisp.setOnClickListener {

            val inStr = edtNum.text.toString()
            var disp = " "

            if (inStr.isNotEmpty()) {       //validating 

                val num = inStr.toInt()
                for (i in 1..10) {
                    val result = num*i
                    disp += "$i x $num = $result\n"
                }

//                var i = 0
//
//                while (i < 11) {
//                    i++
//                    val result = num*i
//                    disp += "$i x $num = $result\n"
//                }
//
//                do {
//                    i++
//                    val result = num * i
//                    disp += "$i x $num = $result\n"
//                }while (i < 10)

                txtDisp.text = disp
            }

            else {
                txtDisp.text = "Enter num"
            }
        }
    }
}